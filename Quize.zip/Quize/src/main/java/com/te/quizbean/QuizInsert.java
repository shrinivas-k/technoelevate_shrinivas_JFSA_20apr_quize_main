package com.te.quizbean;

import java.util.ArrayList;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class QuizInsert {
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {

		Category c1 = new Category();
		c1.setCid(10);
		c1.setCname("General Knowledge");

		Questions q1 = new Questions();
		q1.setQid(1);
		q1.setQuestions("The distance between the popping crease and the bowling crease is:");
		q1.setOpt1("4feet");
		q1.setOpt2("3feet");
		q1.setOpt3("4feet");
		q1.setOpt4("5feet");
		q1.setCorrectAnswer("4feet");
		q1.setCategory(c1);

		Questions q2 = new Questions();
		q2.setQid(2);
		q2.setQuestions(" Which national team are called “Baggy Greens”?");
		q2.setOpt1("Australia");
		q2.setOpt2("India");
		q2.setOpt1("Pakistan");
		q2.setOpt3("Newzeland");
		q2.setCorrectAnswer("Australia");
		q2.setCategory(c1);

		Questions q3 = new Questions();
		q3.setQid(3);
		q3.setQuestions("The 1975 World Cup, the first of its kind was played at:");
		q3.setOpt1("India");
		q3.setOpt2("Pakistan");
		q3.setOpt1("Lords london");
		q3.setOpt3("Australia");
		q3.setCorrectAnswer("Lords london");
		q3.setCategory(c1);

		Questions q4 = new Questions();
		q4.setQid(4);
		q4.setQuestions(" Who was the player of the IPL 2017 season?");
		q4.setOpt1("Kohli");
		q4.setOpt2("Sachin tendulkar");
		q4.setOpt1("Benstokes");
		q4.setOpt3("Rohit");
		q4.setCorrectAnswer("Benstokes");
		q4.setCategory(c1);
		Questions q5 = new Questions();
		q4.setQid(5);
		q4.setQuestions(" Who is called as God of cricket");
		q4.setOpt1("Kohli");
		q4.setOpt2("Sachin tendulkar");
		q4.setOpt1("Benstokes");
		q4.setOpt3("Bumra");
		q4.setCorrectAnswer("Sachin Tendulkar");
		q4.setCategory(c1);

		ArrayList<Questions> array = new ArrayList<Questions>();
		array.add(q1);
		array.add(q2);
		array.add(q3);
		array.add(q4);

		c1.setQuestions(array);

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("quizdata");
		EntityManager entitymanager = emf.createEntityManager();
		EntityTransaction transaction = entitymanager.getTransaction();

		transaction.begin();

		entitymanager.persist(c1);

		transaction.commit();
	}
}
